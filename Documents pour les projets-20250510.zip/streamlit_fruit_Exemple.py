# -*- coding: utf-8 -*-
"""
Created on Tue Mar 28 08:48:18 2023

@author: Hosseini
"""

import streamlit as st
import cv2
from PIL import Image, ImageOps
import numpy as np
from tensorflow.keras.models import model_from_json

nom_classe=["Pomme","Banane","Avocat","Cerise","Kiwi","Mangue","Orange","Ananas","Fraise","Pasteque"]

@st.cache_data
def load_model():
    model_architecture = 'model_fruit.json'
    model_weights = 'model_fruit.h5'
    model = 	model_from_json(open(model_architecture).read())
    model.load_weights(model_weights)  
    return model

with st.spinner('Model is being loaded..'):
  model=load_model()
 
st.write("""
         # Classification des fruits         """
         )
 
file = st.file_uploader("Upload the image to be classified", type=["jpg", "png", "jpeg"])
st.set_option('deprecation.showfileUploaderEncoding', False)
 
def upload_predict(image, model):  
        image = np.asarray(image)
        image=image.astype('float32')
        image=cv2.resize(image,(224,224))
        image /= 255
        image = image.reshape([-1,224,224,3])
        prediction = model.predict(image)
        pred_class=np.argmax(prediction, axis=1)       
        return pred_class, prediction
    
if file is None:
    st.text("Please upload an image file")
else:
    image = Image.open(file)
    st.image(image, use_column_width=True)
    pred_class, prediction = upload_predict(image, model)
    st.write("The image is classified as",nom_classe[pred_class[0]])
    st.write("The probability is", prediction[0][pred_class[0]])
